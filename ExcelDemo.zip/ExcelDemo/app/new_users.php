<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class new_users extends Model
{
    // public $table = 'new_users';
    public function getdata(){
        $data = DB::table('new_users')->select('id, name, email')->get()->toarray();
        return $data;
    }
    protected $fillable = [
      'id',
      'name',
      'email'
    ];
  
}
