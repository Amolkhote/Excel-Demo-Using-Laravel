<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\DB;

class Post extends Model
{
    //
    // public $table = 'SELECT id, name, email FROM `new_users`';
   public static function getdata(){
    $data = DB::table('new_users')->select('user_id', 'name', 'email')->get()->toarray();
    return $data;
   }

    
  
}
