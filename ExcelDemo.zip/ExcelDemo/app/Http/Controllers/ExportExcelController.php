<?php

namespace App\Http\Controllers;

use App\new_users;
use App\Post;
use App\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Facades\Excel;;

class ExportExcelController extends Controller
{
    //
    function index()
    {
     $customer_data = DB::select('SELECT name, email FROM `new_users`');
     return view('export_excel',array('data'=>$customer_data));
    // print_r($customer_data);
    }

    function excel(){
        $data = DB::select('SELECT name, email FROM `new_users`');
        $stu_data[]=array('Name', 'Email');
        foreach($data as $apk){
            $stu_data[]=array(
                'Name'=>$apk->name,
                'Email'=>$apk->email
            );
        }
        // Excel::raw('stu data',function($excel) use ($stu_data){
        //     $excel->setTitle('stu data');
        //     $excel->sheet('stu data', function($sheet) use ($stu_data){
        //         $sheet->fromArray($stu_data, null,'A1',false,false);
        //     });
        // })->download('xlsx');





            return Excel::download(new demo,'Student Data.xlsx');



    }
}

class demo implements FromCollection, WithHeadings
{
    public function collection()
    {
    //    return Post::all();

       return collect(Post::getdata());

        // return $stu_data;
        
    }
    public function headings(): array
    {
        return[
            'id',
            'name',
            'email'
        ];
    }
}