<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class My extends Controller
{
    //

    public function headings(): array
    {
        return [
            '#',
            'Name',
            'Email',
            'Created at',
            'Updated at'
        ];
    }
}
